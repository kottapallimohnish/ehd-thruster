# EHD thruster: stage 3 flow case (coarse mesh, ready to run)

Air driven by the ion body force from the stage 2 space-charge model, flowing through the 7 copper
tubes and the two printed frames. 2D (one cell thick), laminar, transient, `pimpleFoam`.
37 892 cells; ion force grouped into 60 cell zones (`constant/fvOptions`, `constant/polyMesh/cellZones`).

## Run
Needs OpenFOAM, **ESI version** (openfoam.com; built with v1912, newer v2xxx should work) and Python 3 with numpy.

    ./Allrun          # 2 cores; ./Allrun 4 for 4 cores, ./Allrun 1 for serial

It runs 0–2.0 s of flow, writes the fields every 0.02 s (about 350 MB), and finishes by
running `check_anemometer.py`.

## Expected result
    anemometer velocity, time mean : 0.687 m/s (reference)
The flow is unsteady (vortex shedding behind the tubes, a flapping jet). A different OpenFOAM
version, compiler or core count gives a different sequence of eddies, so agreement within about
5–10 % is a successful reproduction.

## If it fails
- `injectionRateSuSp` or `vectorSemiImplicitSource` errors: the force-source syntax changed in your
  OpenFOAM version. Send the error message and the version (`echo $WM_PROJECT_VERSION`).
- Very slow on a Windows drive (`/mnt/d/...`): copy the case into the Linux home folder
  (`cp -r /mnt/d/... ~/`), run it there, and copy the results back.
- `./Allclean` resets the case.

## Coordinates and units
x = across the opening, y = flow direction (wire plane at y = 0, tube centres at y = 14.11 mm),
z = depth (1 mm, 'empty'). Metres. U in m/s; p is kinematic pressure (p/ρ).

"""
Reproduction check for the EHD thruster flow case (coarse mesh, baseline ion force).

Reads the OpenFOAM results in this folder and reports the air speed the anemometer would see:
a 25 mm-wide vane centred on the jet axis, 60 mm behind the back of the copper tubes
(y = 77.1 mm), area-weighted over cells within +-2 mm of that line, averaged over 0.8-2.0 s.

Reference result (OpenFOAM v1912, 2 cores): 0.687 m/s.
The flow is unsteady, so a different OpenFOAM version or core count gives a different
sequence of eddies; expect agreement within about 5-10 %, not to the last digit.

Usage (inside this case folder, after the run and reconstructPar):
    python3 check_anemometer.py
Needs only numpy.
"""
import re
from pathlib import Path

import numpy as np

CASE = Path(__file__).parent
ANEMO_Y_MM, VANE_HALF_MM, BAND_MM = 77.11, 12.5, 2.0
T_START = 0.8
REFERENCE = 0.687


def read_list(path, kind):
    txt = Path(path).read_text()
    txt = txt[txt.index("}", txt.index("FoamFile")) + 1:]
    lines = [l for l in txt.splitlines() if l.strip() and not l.strip().startswith("//")]
    n = int(lines[0])
    body = lines[2:2 + n]
    if kind == "label":
        return np.array(list(map(int, body)))
    if kind == "point":
        return np.array([list(map(float, l.strip("()").split())) for l in body])
    return [list(map(int, l[l.index("(") + 1:l.rindex(")")].split())) for l in body]


def cell_geometry():
    """Centres (mm) and areas (m^2) of the prism cells (one extruded layer)."""
    pm = CASE / "constant/polyMesh"
    pts = read_list(pm / "points", "point")
    faces = read_list(pm / "faces", "face")
    own = read_list(pm / "owner", "label")
    nei = read_list(pm / "neighbour", "label")
    cell_pts = [set() for _ in range(own.max() + 1)]
    for f, c in enumerate(own):
        cell_pts[c].update(faces[f])
    for f, c in enumerate(nei):
        cell_pts[c].update(faces[f])
    C = np.zeros((len(cell_pts), 2))
    A = np.zeros(len(cell_pts))
    for c, ps in enumerate(cell_pts):
        q = pts[sorted(ps)]
        C[c] = q[:, :2].mean(0)
        t = q[q[:, 2] < q[:, 2].mean()][:, :2]
        A[c] = 0.5 * abs((t[1, 0] - t[0, 0]) * (t[2, 1] - t[0, 1]) - (t[2, 0] - t[0, 0]) * (t[1, 1] - t[0, 1]))
    return C * 1e3, A


def read_U(tdir):
    txt = (tdir / "U").read_text()
    i = txt.index("internalField")
    j = txt.index("(", txt.index("List<vector>", i))
    body = txt[j + 1: txt.index("\n)\n", j)]
    return np.array([list(map(float, r.split())) for r in re.findall(r"\(([^()]+)\)", body)])


def main():
    C, A = cell_geometry()
    sel = (np.abs(C[:, 1] - ANEMO_Y_MM) <= BAND_MM) & (np.abs(C[:, 0]) <= VANE_HALF_MM)
    times = sorted((d for d in CASE.iterdir() if re.fullmatch(r"[0-9.e-]+", d.name) and d.is_dir()
                    and float(d.name) >= T_START - 1e-9), key=lambda d: float(d.name))
    if not times:
        raise SystemExit("No time folders >= 0.8 s found. Run the case and reconstructPar first.")
    v = np.array([(read_U(d)[sel, 1] * A[sel]).sum() / A[sel].sum() for d in times])
    print(f"{len(times)} snapshots from {times[0].name} to {times[-1].name} s, {sel.sum()} cells in the vane band")
    print(f"anemometer velocity, time mean : {v.mean():.3f} m/s   (reference {REFERENCE} m/s, "
          f"difference {100 * (v.mean() / REFERENCE - 1):+.1f} %)")
    print(f"fluctuation (std over time)   : {v.std():.3f} m/s")


if __name__ == "__main__":
    main()
